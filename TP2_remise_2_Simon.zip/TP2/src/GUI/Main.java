package GUI;

import javax.swing.SwingUtilities;

/**
 * Travail Pratique 2 INF111
 *
 * <p>L'objectif de ce travail pratique est de </p>
 *
 * <p>Classe	: Main</p>
 *
 * <p>Desc		: Programme permettant de d'ouvrir la fenêtre de recherche et
 *                de remplacement</p>
 *
 * @author Josue Jesus Aliaga Guillen, Noah Boivin, Simon Dion, Souhayl Farsane
 *
 * @version 14/07/24
 */

public class Main {
	
	public static void main(String[] args) {
		
		Cadre cadre = new Cadre("Rechercher/Remplacer");
		
		// On passe la référence pour démarrage de l'application.
		SwingUtilities.invokeLater(cadre);
	}

}

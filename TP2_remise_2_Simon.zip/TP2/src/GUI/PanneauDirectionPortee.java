package GUI;

import javax.swing.BoxLayout;
import javax.swing.JPanel;

/**
 * Travail Pratique 2 INF111
 *
 * <p>L'objectif de ce travail pratique est de créer </p>
 *
 * <p>Classe	: GUI.PanneauDirectionPortee</p>
 *
 * <p>Desc		: Panneau (JPanel) dans lequel se trouve les panneaux de direction
 * 				  et de portée. On fait ce panneau parent, car on veut
		          avoir ses deux panneaux enfants l'un à côter de l'autre.</p>
 *
 * @author Josue Jesus Aliaga Guillen, Noah Boivin, Simon Dion, Souhayl Farsane
 *
 * @version 14/07/24
 */

public class PanneauDirectionPortee extends JPanel{
	
	// le panneau contenant le choix de direction
	private JPanel panneauDirection;
	
	// le panneau comportant le choix de portée
	private JPanel panneauPortee;
	
	/**
	 * Construit un panneau comportant les panneaux de directions et de portée.
	 *
	 * @param panneauPrincipal le panneau principal pour qu'on puisse 
	 *        interagir entre nos classes de panneaux.
	 */
	public PanneauDirectionPortee(JPanel panneauPrincipal) {
		
		// met box layout pour que les panneaux imbriqués soient un à 
		//côté de l'autre.
		setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		
		// construit le panneau où on insère nos choix de direction (JCheckBox)
		// et lui passe le panneau principal en paramètre pour qu'on puisse
		// interagir entre nos classes de panneaux
		panneauDirection = new PanneauDirection(panneauPrincipal);
		
		// construit le panneau où on insère nos choix de portée (JCheckBox)
		// et lui passe le panneau principal en paramètre pour qu'on puisse
		// interagir entre nos classes de panneaux
		panneauPortee = new PanneauPortee(panneauPrincipal);
		
		// ajoute tous les panneaux enfants créés au panneau parent
		add(panneauDirection);
		add(panneauPortee);
		
	}

}

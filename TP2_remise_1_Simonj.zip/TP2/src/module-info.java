/**
 * 
 */
/**
 * @author Simon Dion
 *
 */
module TP2 {
	requires java.desktop;
}
package GUI;

import javax.swing.SwingUtilities;

public class Main {
	
	public static void main(String[] args) {
		
		Cadre cadre = new Cadre("Rechercher/Remplacer");
		
		// On passe la référence pour démarrage de l'application.
		SwingUtilities.invokeLater(cadre);
	}

}

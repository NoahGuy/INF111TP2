package GUI;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Cadre extends JFrame implements Runnable {
	
	private JPanel panneauPrincipal;
	
	public Cadre(String titre) {
		
		super(titre);
		
		this.setSize(600, 600);
	}

	@Override
	public void run() {
		
		panneauPrincipal = new PanneauPrincipal();
		
		setContentPane(panneauPrincipal);			
			
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				
		setVisible(true);
		
	}

}

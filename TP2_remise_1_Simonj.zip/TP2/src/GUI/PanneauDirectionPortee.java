package GUI;

import javax.swing.BoxLayout;
import javax.swing.JPanel;

public class PanneauDirectionPortee extends JPanel{
	
	private JPanel panneauDirection;
	
	private JPanel panneauPortee;
	
	public PanneauDirectionPortee() {
		
		// met box layout pour que les panneaux imbriqués soient un à 
		//côté de l'autre.
		setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		
		panneauDirection = new PanneauDirection();
		panneauPortee = new PanneauPortee();
		
		add(panneauDirection);
		add(panneauPortee);
		
	}

}

package GUI;

import javax.swing.BoxLayout;
import javax.swing.JPanel;

public class PanneauPrincipal extends JPanel{
	
	private JPanel panneauMots;
	
	private JPanel panneauDirectionPortee;
	
	private JPanel panneauOptions;
	
	private JPanel panneauBtn;
	
	private JPanel panneauFermer;
	
	public PanneauPrincipal() {
		
		// met box layout pour que les panneaux imbriques soient les uns par
		// dessus les autres
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		
		panneauMots = new PanneauMots();
		panneauDirectionPortee = new PanneauDirectionPortee();
		panneauOptions = new PanneauOptions();
		panneauBtn = new PanneauBtn();
		panneauFermer = new PanneauFermer();
		
		add(panneauMots);
		add(panneauDirectionPortee);
		add(panneauOptions);
		add(panneauBtn);
		add(panneauFermer);
	}
}

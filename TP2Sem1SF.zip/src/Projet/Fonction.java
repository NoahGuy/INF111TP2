package Projet;

public class Fonction {
    private CadreGUI cadre;

    public Fonction(CadreGUI cadre) {
        this.cadre = cadre;
    }

    public void nouveauFichier() {
        cadre.getPanneauPrincipal().getText().setText("");
        cadre.setTitle("Nouvelle page");
    }

    // Ajouter les méthodes de sauvegarde ici
}

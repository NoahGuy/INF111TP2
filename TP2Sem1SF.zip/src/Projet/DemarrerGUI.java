package Projet;

import javax.swing.*;

public class DemarrerGUI {
    public static void main(String[] args) {
        new CadreGUI();
    }
}

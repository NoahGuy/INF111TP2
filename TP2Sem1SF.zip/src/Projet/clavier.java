package Projet;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

public class clavier implements KeyListener, MouseWheelListener {
    private CadreGUI gui;

    public clavier(CadreGUI gui) {
        this.gui = gui;
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // rien
    }

    @Override
    public void keyPressed(KeyEvent e) {
        // rien
    }

    @Override
    public void keyReleased(KeyEvent e) {
        // rien
    }

    /**
     * Quand je scroll up ou down ya une action listener qui appel soit zoom in ou out celon la direction du scroll
     * @param e the event to be processed
     */
    @Override
    public void mouseWheelMoved(MouseWheelEvent e) {
        if ((e.getModifiersEx() & KeyEvent.CTRL_DOWN_MASK) != 0) {
            if (e.getWheelRotation() < 0) {
                zoomIn();
            } else {
                zoomOut();
            }
        }
    }

    /**
     *
     */
    private void zoomIn() {//gpt
        JTextArea textArea = gui.getPanneauPrincipal().getText();
        Font currentFont = textArea.getFont();
        float newSize = currentFont.getSize() + 2.0f;
        textArea.setFont(currentFont.deriveFont(newSize));
        gui.setStatus("ZOOM");
    }

    /**
     *
     */
    private void zoomOut() {//gpt
        JTextArea textArea = gui.getPanneauPrincipal().getText();
        Font currentFont = textArea.getFont();
        float newSize = currentFont.getSize() - 2.0f;
        if (newSize > 0) {
            textArea.setFont(currentFont.deriveFont(newSize));
            gui.setStatus("DEZOOM");
        }
    }
}
